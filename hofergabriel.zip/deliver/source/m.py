import sys
from demo import demo

print(sys.argv[0])

demo("data/notredame/notre_dame_1.jpg","data/notredame/notre_dame_2.jpg",0.5,0.5,0.0001)
demo("data/rushmore/rush1.jpg","data/rushmore/rush0.jpg",0.12,0.04,0.00001)
demo("data/gaudi/gaudi_1.jpg","data/gaudi/gaudi_2.jpg",0.7,0.3,0.001)

#demo("data/plane.bmp","data/plane.bmp")
#demo(sys.argv[1],sys.argv[2],.5,.5,0.0001)


